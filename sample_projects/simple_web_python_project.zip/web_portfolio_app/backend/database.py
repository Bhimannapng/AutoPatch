import os

# 1. SECURITY VULNERABILITY (Aegis): Hardcoded Secret
DATABASE_API_KEY = "sk_live_98374928374982374982"

def get_db_connection():
    print("Connecting to database using API key:", DATABASE_API_KEY)
    return {"status": "connected"}

def find_user_by_email(email):
    # 2. SECURITY VULNERABILITY (Aegis): Raw SQL Injection
    query = "SELECT * FROM users WHERE email = '" + email + "'"
    return query
