import pytest
from marks_calculator import calculate_grade

def test_normal_marks():
    assert calculate_grade(95) == "Grade A"
    assert calculate_grade(80) == "Grade B"
    assert calculate_grade(60) == "Grade C"

def test_minimum_boundary():
    assert calculate_grade(0) == "Fail"
    assert calculate_grade(50) == "Grade C"

def test_maximum_boundary():
    assert calculate_grade(100) == "Grade A"

def test_invalid_negative_marks():
    # Should reject negative values
    res = calculate_grade(-10)
    assert res in ("Invalid Marks", "Error", "Invalid") or isinstance(res, ValueError)

def test_invalid_overflow_marks():
    # Should reject marks above 100
    res = calculate_grade(150)
    assert res in ("Invalid Marks", "Error", "Invalid") or isinstance(res, ValueError)
